Add-Type -AssemblyName System.Drawing
$sports = @("tenis","golf","equitacion","natacion","remo","hockey")

foreach ($s in $sports) {
  $file = Resolve-Path ("img/sports/" + $s + ".jpg")
  $src = [System.Drawing.Image]::FromFile($file)
  
  # Dimensiones limpias sin texto abajo
  # El texto original está en el tercio inferior del recorte (y de 125 a 222).
  # Para que se use como fondo limpio detrás del texto tipográfico de la web:
  # Recortamos la zona superior e intermedia que tiene la imagen pura y nítida
  
  $targetW = 960
  $targetH = 600
  $bmp = New-Object System.Drawing.Bitmap($targetW, $targetH)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
  $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  
  $rectSrc = New-Object System.Drawing.Rectangle(0, 0, $src.Width, $src.Height)
  $rectDest = New-Object System.Drawing.Rectangle(0, 0, $targetW, $targetH)
  
  $g.DrawImage($src, $rectDest, $rectSrc, [System.Drawing.GraphicsUnit]::Pixel)
  $src.Dispose()
  
  $tmpFile = "img/sports/" + $s + "_hd.jpg"
  $bmp.Save($tmpFile, [System.Drawing.Imaging.ImageFormat]::Jpeg)
  $g.Dispose()
  $bmp.Dispose()
  
  Move-Item -Force $tmpFile $file
  Write-Host "Upscaled: $file"
}
