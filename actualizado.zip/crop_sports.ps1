Add-Type -AssemblyName System.Drawing
$imgPath = Resolve-Path "img/sports/sports_grid.jpg"
$src = [System.Drawing.Image]::FromFile($imgPath)

$crops = @(
  @{ name="tenis.jpg";      x=5;   y=5;   w=331; h=222 },
  @{ name="golf.jpg";       x=345; y=5;   w=335; h=222 },
  @{ name="equitacion.jpg"; x=688; y=5;   w=331; h=222 },
  @{ name="natacion.jpg";   x=5;   y=236; w=331; h=222 },
  @{ name="remo.jpg";       x=345; y=236; w=335; h=222 },
  @{ name="hockey.jpg";     x=688; y=236; w=331; h=222 }
)

foreach ($c in $crops) {
  $bmp = New-Object System.Drawing.Bitmap([int]$c.w, [int]$c.h)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
  $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  
  $rectSrc = New-Object System.Drawing.Rectangle([int]$c.x, [int]$c.y, [int]$c.w, [int]$c.h)
  $rectDest = New-Object System.Drawing.Rectangle(0, 0, [int]$c.w, [int]$c.h)
  
  $g.DrawImage($src, $rectDest, $rectSrc, [System.Drawing.GraphicsUnit]::Pixel)
  $outPath = Join-Path (Resolve-Path "img/sports") $c.name
  $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Jpeg)
  $g.Dispose()
  $bmp.Dispose()
  Write-Host "Created: $outPath"
}

$src.Dispose()
